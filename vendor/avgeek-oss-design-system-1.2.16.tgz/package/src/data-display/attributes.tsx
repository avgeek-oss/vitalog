"use client";

import {
  createContext,
  forwardRef,
  type ComponentPropsWithRef,
  type ReactNode,
  useContext,
} from "react";
import { Widget } from "./widget.js";
import {
  AttributeListFrame,
  attributeListRowSpacing,
} from "./attribute-list-frame.js";
import { cn } from "../lib/utils.js";
import { HeadingHelp } from "../overlays/heading-help.js";

export type AttributesVariant = "card" | "embedded" | "list";
export type AttributesColumns = 1 | 2 | 3;
const VariantContext = createContext<AttributesVariant>("list");
const columns = {
  1: "grid-cols-1",
  2: "grid-cols-2",
  3: "grid-cols-2 lg:grid-cols-3",
} as const;

type AttributesSharedProps = Omit<
  ComponentPropsWithRef<"div">,
  "children" | "title"
> & {
  children: ReactNode;
  columns?: AttributesColumns;
  icon?: ReactNode;
};
export type AttributesProps = AttributesSharedProps &
  (
    | { title?: ReactNode; variant: "embedded" }
    | { title: ReactNode; variant?: Exclude<AttributesVariant, "embedded"> }
  );
const Root = forwardRef<HTMLDivElement, AttributesProps>(
  (
    {
      children,
      className,
      columns: count = 2,
      icon,
      title,
      variant = "list",
      ...props
    },
    ref,
  ) => {
    if (variant === "embedded")
      return (
        <VariantContext.Provider value={variant}>
          <div
            ref={ref}
            className={cn("grid min-w-0 gap-1", className)}
            {...props}
          >
            {title != null ? (
              <span className="inline-flex min-w-0 items-center gap-2 text-xs font-medium text-muted">
                {icon ? (
                  <span aria-hidden="true" className="inline-flex shrink-0">
                    {icon}
                  </span>
                ) : null}
                <span className="truncate">{title}</span>
                <HeadingHelp title={typeof title === "string" ? title : ""} />
              </span>
            ) : null}
            <dl className="grid">{children}</dl>
          </div>
        </VariantContext.Provider>
      );
    if (variant === "list")
      return (
        <VariantContext.Provider value={variant}>
          <AttributeListFrame
            ref={ref}
            title={title}
            icon={icon}
            className={className}
            {...props}
          >
            <dl className="grid">{children}</dl>
          </AttributeListFrame>
        </VariantContext.Provider>
      );
    return (
      <VariantContext.Provider value={variant}>
        <Widget
          ref={ref}
          className={cn("min-w-0 overflow-hidden", className)}
          {...props}
        >
          <Widget.Header>
            <Widget.Title
              icon={icon}
              className="min-w-0 truncate text-xs font-medium text-muted"
            >
              {title}
            </Widget.Title>
          </Widget.Header>
          <Widget.Content>
            <dl className={cn("content-grid", columns[count])}>{children}</dl>
          </Widget.Content>
        </Widget>
      </VariantContext.Provider>
    );
  },
);
Root.displayName = "Attributes.Root";
export interface AttributesItemProps extends Omit<
  ComponentPropsWithRef<"div">,
  "children"
> {
  children: ReactNode;
  icon?: ReactNode;
  label: ReactNode;
}
const Item = forwardRef<HTMLDivElement, AttributesItemProps>(
  ({ children, className, icon, label, ...props }, ref) => {
    const variant = useContext(VariantContext);
    return (
      <div
        ref={ref}
        className={cn(
          "attributes__item",
          variant === "card"
            ? "grid min-w-0 gap-1"
            : cn(
                "flex min-w-0 items-center justify-between gap-4 border-b border-separator py-3 last:border-0",
                variant === "list" && attributeListRowSpacing,
                variant === "embedded" && "first:pt-0 last:pb-0",
              ),
          className,
        )}
        {...props}
      >
        <dt className="flex min-w-0 items-center gap-2 text-sm font-normal text-muted">
          {icon ? (
            <span aria-hidden className="[&_svg]:size-4">
              {icon}
            </span>
          ) : null}
          {label}
        </dt>
        <dd
          className={cn(
            "min-w-0 text-sm font-normal",
            variant === "list" && "text-end",
          )}
        >
          {children}
        </dd>
      </div>
    );
  },
);
Item.displayName = "Attributes.Item";
export const Attributes = Object.assign(Root, { Item, Root });
export { Item as AttributesItem, Root as AttributesRoot };
