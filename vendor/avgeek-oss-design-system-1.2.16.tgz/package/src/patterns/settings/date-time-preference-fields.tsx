"use client";

import { useMemo, useState } from "react";
import { defaultDateTimePreferences } from "../../utilities/date-time-preferences.js";
export type DateTimePreferences = {
  dateFormat: string;
  timeFormat: string;
  timeZone: string;
};
import { Label } from "../../forms/label.js";
import { Select, ListBox } from "../../forms/select.js";
import { Autocomplete, SearchField } from "../../pickers/autocomplete.js";
import { timeZoneOffset } from "../../lib/time-zone-offset.js";

export type DateTimePreferenceOptions = {
  dateFormats: ReadonlyArray<{
    id: DateTimePreferences["dateFormat"];
    label: string;
  }>;
  timeFormats: ReadonlyArray<{
    id: DateTimePreferences["timeFormat"];
    label: string;
  }>;
  timeZones: readonly string[];
};

export function browserDateTimePreferences(
  options: DateTimePreferenceOptions,
): DateTimePreferences {
  const browserTimeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
  return {
    dateFormat:
      options.dateFormats[0]?.id ?? defaultDateTimePreferences.dateFormat,
    timeFormat:
      options.timeFormats[0]?.id ?? defaultDateTimePreferences.timeFormat,
    timeZone: options.timeZones.includes(browserTimeZone)
      ? browserTimeZone
      : defaultDateTimePreferences.timeZone,
  };
}

export function DateTimePreferenceFields({
  disabled,
  onChange,
  options,
  preferences,
  variant = "primary",
}: {
  disabled?: boolean;
  onChange: (preferences: DateTimePreferences) => void;
  options: DateTimePreferenceOptions;
  preferences: DateTimePreferences;
  variant?: "primary" | "secondary";
}) {
  const [offsetInstant, setOffsetInstant] = useState(() => new Date());
  const offsets = useMemo(
    () =>
      new Map(
        options.timeZones.map((zone) => [
          zone,
          timeZoneOffset(zone, offsetInstant),
        ]),
      ),
    [options.timeZones, offsetInstant],
  );
  return (
    <>
      <div className="grid gap-4 sm:grid-cols-2">
        <Select
          variant={variant}
          fullWidth
          isRequired
          isDisabled={disabled}
          selectedKey={preferences.dateFormat}
          onSelectionChange={(key) => {
            const option = options.dateFormats.find((item) => item.id === key);
            if (option) onChange({ ...preferences, dateFormat: option.id });
          }}
        >
          <Label isRequired>Date format</Label>
          <Select.Trigger>
            <Select.Value />
            <Select.Indicator />
          </Select.Trigger>
          <Select.Popover>
            <ListBox>
              {options.dateFormats.map((option) => (
                <ListBox.Item
                  id={option.id}
                  key={option.id}
                  textValue={option.label}
                >
                  {option.label}
                  <ListBox.ItemIndicator />
                </ListBox.Item>
              ))}
            </ListBox>
          </Select.Popover>
        </Select>
        <Select
          variant={variant}
          fullWidth
          isRequired
          isDisabled={disabled}
          selectedKey={preferences.timeFormat}
          onSelectionChange={(key) => {
            const option = options.timeFormats.find((item) => item.id === key);
            if (option) onChange({ ...preferences, timeFormat: option.id });
          }}
        >
          <Label isRequired>Time format</Label>
          <Select.Trigger>
            <Select.Value />
            <Select.Indicator />
          </Select.Trigger>
          <Select.Popover>
            <ListBox>
              {options.timeFormats.map((option) => (
                <ListBox.Item
                  id={option.id}
                  key={option.id}
                  textValue={option.label}
                >
                  {option.label}
                  <ListBox.ItemIndicator />
                </ListBox.Item>
              ))}
            </ListBox>
          </Select.Popover>
        </Select>
      </div>
      <Select
        variant={variant}
        fullWidth
        isRequired
        isDisabled={disabled}
        selectedKey={preferences.timeZone}
        onOpenChange={(open) => {
          if (open) setOffsetInstant(new Date());
        }}
        onSelectionChange={(key) => {
          if (typeof key === "string" && options.timeZones.includes(key))
            onChange({ ...preferences, timeZone: key });
        }}
      >
        <Label isRequired>Time zone</Label>
        <Select.Trigger>
          <Select.Value className="min-w-0 flex-1">
            <span className="flex min-w-0 items-center gap-3">
              <span className="truncate">{preferences.timeZone}</span>
              <span className="ml-auto shrink-0 tabular-nums text-muted">
                {offsets.get(preferences.timeZone)}
              </span>
            </span>
          </Select.Value>
          <Select.Indicator />
        </Select.Trigger>
        <Select.Popover className="w-(--trigger-width) min-w-[min(18rem,calc(100vw-2rem))] max-w-[calc(100vw-2rem)] flex flex-col overflow-hidden">
          <Autocomplete.Filter
            filter={(text, search) =>
              text
                .toLocaleLowerCase()
                .includes(search.trim().toLocaleLowerCase())
            }
          >
            <SearchField
              aria-label="Search time zones"
              className="relative z-10 shrink-0 bg-overlay px-2 pt-2 pb-2"
              variant="secondary"
            >
              <SearchField.Group className="rounded-md">
                <SearchField.SearchIcon />
                <SearchField.Input
                  className="text-base sm:text-sm"
                  placeholder="Search time zones…"
                  maxLength={200}
                  autoComplete="off"
                  spellCheck={false}
                  autoFocus={
                    typeof window !== "undefined" &&
                    window.matchMedia("(pointer: fine)").matches
                  }
                />
                <SearchField.ClearButton aria-label="Clear time zone search" />
              </SearchField.Group>
            </SearchField>
            <ListBox className="min-h-0 flex-1 overflow-y-auto overscroll-contain">
              {options.timeZones.map((zone) => (
                <ListBox.Item id={zone} key={zone} textValue={zone}>
                  <span className="flex min-w-0 flex-1 items-center gap-3">
                    <span className="truncate">{zone}</span>
                    <span className="ml-auto shrink-0 tabular-nums text-muted">
                      {offsets.get(zone)}
                    </span>
                  </span>
                  <ListBox.ItemIndicator />
                </ListBox.Item>
              ))}
            </ListBox>
          </Autocomplete.Filter>
        </Select.Popover>
      </Select>
    </>
  );
}
